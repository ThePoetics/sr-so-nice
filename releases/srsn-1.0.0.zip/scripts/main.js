Hooks.once('diceSoNiceInit', (dice3d) => {
    dice3d.addTexture("Beans", {
        name: "Beans",
        composite: "source-over",
        source: "modules/bean-dice/images/beans.png",
        bump:"modules/bean-dice/images/beans.png"
    });

});
